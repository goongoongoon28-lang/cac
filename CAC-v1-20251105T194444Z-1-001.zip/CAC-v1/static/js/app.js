// ========================================================================
// Flood Sentinel - Professional Frontend Application
// Interactive map, live data, and beautiful visualizations
// ========================================================================

// Global variables
let map;
let markersLayer;
let heatLayer;
let riskChart;
let allPredictions = [];
let currentVizMode = 'heat'; // 'heat' | 'points' (houses mode removed)
let weatherUpdateTimeout = null;
let areaCircle = null;
let userAnchor = null; // {lat, lng} once geolocated
let areaRadiusMeters = 8047; // ~5 miles
// Algorithm-only mode (no ML option)
let buildingEstimate = null; // latest OSM building estimate for area
let radarLayer = null;
let radarOn = false;
let areaUpdateTimeout = null;
let heatAutoScale = false;
let baseTilesLight = null;
let baseTilesDark = null;
let baseTilesCurrent = null;
let allowHeatOverlay = false;
let lastHeatFeatures = null;
let lastGridSpacingM = 150;

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', async function() {
    console.log('🌊 FloodScope - Initializing...');
    
    const loadingOverlay = document.getElementById('loading-overlay');
    const loadingText = loadingOverlay ? loadingOverlay.querySelector('p') : null;
    
    try {
        // Initialize map
        if (loadingText) loadingText.textContent = 'Initializing map...';
        initializeMap();
        
        // Check server health first
        if (loadingText) loadingText.textContent = 'Connecting to server...';
        const healthCheck = await fetch('/api/health').catch(err => {
            throw new Error('Server not responding. Please ensure the Flask server is running.');
        });
        
        if (!healthCheck.ok) {
            throw new Error(`Server returned error: ${healthCheck.status}`);
        }

// ===== HOUSES MODE REMOVED (Points only) =====

// ===== THEME HELPERS =====
function getSavedTheme() {
    try { return localStorage.getItem('theme') || 'dark'; } catch { return 'dark'; }
}

function applyTheme(theme) {
    try { localStorage.setItem('theme', theme); } catch {}
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    // Switch basemap
    if (!map) return;
    const desired = (theme === 'dark') ? baseTilesDark : baseTilesLight;
    if (baseTilesCurrent) {
        try { map.removeLayer(baseTilesCurrent); } catch {}
    }
    if (desired) {
        desired.addTo(map);
        baseTilesCurrent = desired;
    }
}

// ===== LOCATION LABEL (Reverse Geocode) =====
function updateLocationLabelFromCenter() {
    if (!map) return;
    const c = map.getCenter();
    fetch('/api/reverse-geocode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude: c.lat, longitude: c.lng })
    })
    .then(r => r.json())
    .then(data => {
        const el = document.getElementById('location-label');
        if (el && data && data.label) el.textContent = data.label;
    })
    .catch(() => {
        const el = document.getElementById('location-label');
        if (el) el.textContent = 'Unknown location';
    });
}
        
        
        const healthData = await healthCheck.json();
        if (!healthData.model_loaded) {
            throw new Error('Model not loaded on server');
        }
        
        // Load data
        if (loadingText) loadingText.textContent = 'Loading flood risk data...';
        await Promise.all([
            loadSystemHealth(),
            loadStatistics(),
            fetchAreaPredictions(map.getCenter(), areaRadiusMeters, getCurrentPrecipInches(), true),
            fetchBuildingEstimate(map.getCenter(), areaRadiusMeters),
            refreshForecast(map.getCenter()),
            refreshGauges(map.getCenter()),
            refreshAlerts(map.getCenter())
        ]);
        updateLocationLabelFromCenter();
        
        if (loadingText) loadingText.textContent = 'Loading weather data...';
        updateWeatherWidget();
        
        // Set up event listeners
        setupEventListeners();
        
        // Hide loading overlay after successful load
        console.log('✓ Application initialized successfully');
        setTimeout(() => {
            if (loadingOverlay) loadingOverlay.classList.add('hidden');
        }, 500);
        
    } catch (error) {
        console.error('✗ Initialization error:', error);
        if (loadingText) {
            loadingText.innerHTML = `
                <i class="fas fa-exclamation-triangle" style="color: #f59e0b; font-size: 48px; margin-bottom: 20px;"></i><br>
                <strong style="color: #ef4444;">Failed to connect to server</strong><br><br>
                <span style="font-size: 14px; color: #6b7280;">${error.message}</span><br><br>
                <span style="font-size: 13px; color: #9ca3af;">
                    Please ensure the Flask server is running:<br>
                    <code style="background: rgba(0,0,0,0.1); padding: 4px 8px; border-radius: 4px; margin-top: 8px; display: inline-block;">python app.py</code>
                </span>
            `;
        }
    }
});

// ===== MAP INITIALIZATION =====
function initializeMap() {
    // Initialize Leaflet map (will center on user location)
    map = L.map('map', {
        zoomControl: false
    }).setView([39.8283, -98.5795], 4); // Center of USA, low zoom until user location loads
    
    // Prepare light and dark basemaps
    baseTilesLight = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    });
    baseTilesDark = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '© OpenStreetMap, © CARTO',
        maxZoom: 19
    });
    // Initialize theme and basemap without relying on external helpers
    (function(){
        let themeInit = 'dark';
        try { themeInit = localStorage.getItem('theme') || 'dark'; } catch {}
        document.documentElement.setAttribute('data-theme', themeInit === 'dark' ? 'dark' : 'light');
        baseTilesCurrent = (themeInit === 'dark') ? baseTilesDark : baseTilesLight;
        baseTilesCurrent.addTo(map);
    })();
    
    // Add zoom control to bottom right
    L.control.zoom({
        position: 'bottomright'
    }).addTo(map);
    
    // Initialize marker layer
    markersLayer = L.layerGroup().addTo(map);
    
    // Ensure proper sizing after layout
    setTimeout(() => map.invalidateSize(), 300);
    window.addEventListener('resize', () => map.invalidateSize());
    map.on('moveend', updateWeatherWidget);
    // Update location label when map moves (but don't auto-predict)
    map.on('moveend', () => {
        updateLocationLabelFromCenter();
    });
    // Rebuild heat on zoom to prevent tiling artifacts
    map.on('zoomstart', () => {
        if (heatLayer) { try { map.removeLayer(heatLayer); } catch {} }
    });
    map.on('zoomend', () => {
        // Rebuild heat from existing predictions if available
        if (currentVizMode === 'heat' && allPredictions && allPredictions.length) {
            displayHeatmap(allPredictions);
        }
    });
    window.addEventListener('resize', () => {
        if (currentVizMode === 'heat' && allPredictions.length) {
            if (heatLayer) { try { map.removeLayer(heatLayer); } catch {} }
            displayHeatmap(allPredictions);
        }
    });
    
    // Auto-geolocate on startup
    if (navigator.geolocation) {
        const locLabel = document.getElementById('location-label');
        if (locLabel) locLabel.textContent = 'Getting your location...';
        navigator.geolocation.getCurrentPosition((pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            userAnchor = { lat, lng };
            map.setView([lat, lng], 13);
            if (areaCircle) map.removeLayer(areaCircle);
            areaCircle = L.circle([lat, lng], {
                radius: areaRadiusMeters,
                color: '#667eea',
                fillColor: '#667eea',
                fillOpacity: 0.1,
                weight: 2
            }).addTo(map);
            updateLocationLabelFromCenter();
            if (locLabel) locLabel.textContent = 'Location set. Click Predict to start.';
        }, (err) => {
            console.warn('Geolocation denied/unavailable; using default center.', err);
        }, { enableHighAccuracy: true, timeout: 8000, maximumAge: 120000 });
    }
    
    console.log('✓ Map initialized');
}

// ===== WEATHER WIDGET =====
function updateWeatherWidget() {
    if (!map) return;
    const center = map.getCenter();
    // Debounce rapid calls when panning
    if (weatherUpdateTimeout) clearTimeout(weatherUpdateTimeout);
    weatherUpdateTimeout = setTimeout(() => {
        fetch('/api/live-risk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ latitude: center.lat, longitude: center.lng })
        })
        .then(r => r.json())
        .then(res => {
            if (!res || res.error) throw new Error(res && res.error ? res.error : 'No weather');
            const w = res.weather;
            const el = document.getElementById('current-weather');
            if (w && el) {
                el.textContent = `${w.description} • ${Math.round(w.temperature)}°C`;
            }
        })
        .catch(() => {
            const el = document.getElementById('current-weather');
            if (el) el.textContent = 'Weather unavailable';
        });
    }, 400);
}

// ===== DATA LOADING =====
function loadSystemHealth() {
    return fetch('/api/health')
        .then(response => response.json())
        .then(data => {
            // Update status indicators
            const backendStatus = document.getElementById('backend-status');
            if (data.status === 'healthy') {
                backendStatus.innerHTML = '<i class="fas fa-check-circle"></i> Healthy';
                backendStatus.style.color = '#28a745';
            } else {
                backendStatus.innerHTML = '<i class="fas fa-times-circle"></i> Error';
                backendStatus.style.color = '#dc3545';
            }
            
            // Model status
            const modelStatus = document.getElementById('model-status');
            if (data.model_loaded) {
                modelStatus.innerHTML = '<i class="fas fa-check-circle"></i> Loaded';
                modelStatus.style.color = '#28a745';
            } else {
                modelStatus.innerHTML = '<i class="fas fa-times-circle"></i> Not Loaded';
                modelStatus.style.color = '#dc3545';
            }
            
            // Last update
            const lastUpdate = new Date(data.timestamp).toLocaleString();
            document.getElementById('last-update').textContent = lastUpdate;
            
            console.log('✓ System health loaded');
        })
        .catch(error => {
            console.error('✗ Failed to load system health:', error);
            document.getElementById('backend-status').innerHTML = '<i class="fas fa-times-circle"></i> Error';
            document.getElementById('backend-status').style.color = '#dc3545';
            throw error;
        });
}

function loadStatistics() {
    return fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            // Update statistics
            document.getElementById('stat-low').textContent = formatNumber(data.risk_distribution.low);
            document.getElementById('stat-moderate').textContent = formatNumber(data.risk_distribution.moderate);
            document.getElementById('stat-high').textContent = formatNumber(data.risk_distribution.high);
            document.getElementById('stat-extreme').textContent = formatNumber(data.risk_distribution.extreme);
            document.getElementById('total-locations').textContent = formatNumber(data.total_locations);
            // Homes at risk summary
            if (typeof data.homes_at_risk === 'number') {
                const har = document.getElementById('homes-at-risk');
                const harPct = document.getElementById('homes-at-risk-pct');
                if (har) har.textContent = formatNumber(data.homes_at_risk);
                if (harPct) harPct.textContent = (data.homes_at_risk_percent || 0).toFixed(1);
            }
            
            // Create chart
            createRiskChart(data.risk_distribution);
            
            console.log('✓ Statistics loaded');
        })
        .catch(error => {
            console.error('✗ Failed to load statistics:', error);
            throw error;
        });
}

function getAdaptiveGridSpacing() {
    if (!map) return 150;
    const z = map.getZoom();
    if (z >= 19) return 10;   // driveway/lot scale
    if (z >= 18) return 15;   // cul-de-sac scale
    if (z >= 17) return 25;
    if (z >= 16) return 50;
    if (z >= 15) return 100;
    return 150;
}

function fetchAreaPredictions(centerLatLng, radiusMeters, precipInches, use_osm_water) {
    // Show loading indicator
    const loadingOverlay = document.getElementById('loading-overlay');
    const loadingText = loadingOverlay ? loadingOverlay.querySelector('p') : null;
    if (loadingOverlay) {
        loadingOverlay.classList.remove('hidden');
        if (loadingText) loadingText.textContent = 'Loading predictions...';
    }

    const gridSpacing = getAdaptiveGridSpacing();
    const payload = {
        latitude: centerLatLng.lat,
        longitude: centerLatLng.lng,
        radius_meters: radiusMeters,
        precip_inches: Number(precipInches || 0),
        grid_spacing_meters: gridSpacing,
        max_points: 3500,
        mode: 'algo',  // Algorithm-only mode
        use_osm_water: use_osm_water
    };
    return fetch('/api/predict-grid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            console.error('Server error:', data.error);
            throw new Error(data.error);
        }
        allPredictions = (data && data.features) ? data.features : [];
        if (typeof data.grid_spacing_m === 'number') lastGridSpacingM = data.grid_spacing_m;
        renderVisualization();
        updateAreaStatsFromFeatures(allPredictions);
        // Sync building estimate for this same area
        fetchBuildingEstimate(centerLatLng, radiusMeters);
        console.log(`✓ Grid predictions: ${allPredictions.length} locations (${data.grid_spacing_m}m spacing)`);
    })
    .catch(err => {
        console.error('✗ Failed to load grid predictions:', err);
        throw err;
    })
    .finally(() => {
        // Hide loading indicator
        if (loadingOverlay) {
            setTimeout(() => loadingOverlay.classList.add('hidden'), 300);
        }
    });
}

function fetchBuildingEstimate(centerLatLng, radiusMeters) {
    const payload = {
        latitude: centerLatLng.lat,
        longitude: centerLatLng.lng,
        radius_meters: radiusMeters
    };
    return fetch('/api/building-count', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data && !data.error) {
            buildingEstimate = Number(data.house_like || data.total_buildings || 0);
            const el = document.getElementById('building-estimate');
            if (el) el.textContent = formatNumber(buildingEstimate);
            console.log(`✓ Building estimate: ${buildingEstimate}`);
        }
    })
    .catch(err => {
        console.warn('Building estimate failed:', err);
    });
}

// ===== MAP DISPLAY =====
function renderVisualization() {
    // Toggle legend visibility (show for heat only)
    const legend = document.getElementById('legend-gradient');
    if (legend) legend.style.display = (currentVizMode === 'heat') ? 'flex' : 'none';

    if (currentVizMode === 'heat') {
        displayHeatmap(allPredictions);
    } else if (currentVizMode === 'points') {
        displayMarkersOnMap(allPredictions);
    }
}

function displayHeatmap(features) {
    if (!Array.isArray(features) || features.length === 0) {
        if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
        markersLayer.clearLayers();
        return;
    }

    // If heat plugin missing, fallback to points
    if (typeof L.heatLayer !== 'function') {
        console.warn('Leaflet heat plugin missing; falling back to point markers.');
        displayMarkersOnMap(features);
        return;
    }

    // Remove existing layers
    markersLayer.clearLayers();
    if (heatLayer) { map.removeLayer(heatLayer); }

    // Build heat points: [lat, lon, intensity]
    let probs = features.map(f => Math.max(0, Math.min(1, Number(f.properties.flood_probability))));
    let minP = Math.min.apply(null, probs);
    let maxP = Math.max.apply(null, probs);
    const denom = Math.max(1e-6, maxP - minP);
    const bounds = map ? map.getBounds() : null;
    const pad = 0.05; // allow a bit beyond bounds
    const points = [];
    const rainIn = (typeof getCurrentPrecipInches === 'function') ? Number(getCurrentPrecipInches() || 0) : 0;
    const doScale = heatAutoScale || (rainIn > 0 && (maxP - minP) < 0.08);
    let maxIntensity = 0;
    for (let i = 0; i < features.length; i++) {
        const f = features[i];
        let lat = Number(f?.geometry?.coordinates?.[1]);
        let lon = Number(f?.geometry?.coordinates?.[0]);
        if (!isFinite(lat) || !isFinite(lon)) continue;
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) continue;
        if (bounds) {
            const south = bounds.getSouth() - pad;
            const north = bounds.getNorth() + pad;
            const west  = bounds.getWest()  - pad;
            const east  = bounds.getEast()  + pad;
            if (lat < south || lat > north || lon < west || lon > east) continue;
        }
        const p = probs[i];
        const base = doScale ? ((p - minP) / denom) : p;
        const intensity = Math.max(0.0, Math.min(1.0, base));
        if (intensity > maxIntensity) maxIntensity = intensity;
        points.push([lat, lon, intensity]);
    }

    if (points.length === 0) {
        if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
        return;
    }

    // Dynamic smoothing based on zoom to create soft "clouds"
    const z = map ? map.getZoom() : 13;
    const radius = Math.max(30, Math.min(85, Math.round(35 + (z - 10) * 8)));
    const blur = Math.round(radius * 0.75);

    heatLayer = L.heatLayer(points, {
        radius: radius,
        blur: blur,
        minOpacity: (maxIntensity <= 0.02 ? 0.0 : 0.18),
        maxZoom: 20,
        gradient: {
            0.0: '#10b981',
            0.4: '#f59e0b',
            0.6: '#f97316',
            0.8: '#ef4444'
        }
    }).addTo(map);

    // Remember for rebuilds on zoom
    lastHeatFeatures = features;
}

function displayMarkersOnMap(features) {
    // Clear existing markers
    markersLayer.clearLayers();
    if (heatLayer && !allowHeatOverlay) { map.removeLayer(heatLayer); heatLayer = null; }
    
    // Add markers for each location
    features.forEach(feature => {
        const coords = feature.geometry.coordinates;
        const props = feature.properties;
        
        // Continuous color based on probability
        const color = getColorForProbability(props.flood_probability || 0);

        // Create custom marker
        const marker = L.circleMarker([coords[1], coords[0]], {
            radius: 5 + Math.round((props.flood_probability || 0) * 5),
            fillColor: color,
            color: '#fff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8
        });
        
        // Create popup content
        const popupContent = `
            <div style="min-width: 200px;">
                <h5 style="margin: 0 0 10px 0; color: #2c3e50;">
                    <i class="fas fa-map-marker-alt"></i> ${props.building_id ? 'Building ' + props.building_id : 'Location ' + (props.house_id || '')}
                </h5>
                <div style="margin: 8px 0;">
                    <strong>Risk Level:</strong> 
                    <span class="badge badge-${(props.risk_level||'').toLowerCase()}">${props.risk_level}</span>
                </div>
                <div style="margin: 8px 0;">
                    <strong>Flood Probability:</strong> ${(props.flood_probability * 100).toFixed(1)}%
                </div>
                <div style="margin: 8px 0;">
                    <strong>Elevation:</strong> ${Number(props.elevation_m||0).toFixed(1)}m
                </div>
                <div style="margin: 8px 0;">
                    <strong>Distance to Water:</strong> ${Number(props.distance_to_water_m||0).toFixed(0)}m
                </div>
                ${props.hsg ? `<div style="margin: 8px 0;"><strong>Soil Group:</strong> ${props.hsg}</div>` : ''}
                ${props.soil_permeability_mm_hr ? `<div style=\"margin: 8px 0;\"><strong>Soil Permeability:</strong> ${Number(props.soil_permeability_mm_hr).toFixed(1)} mm/hr</div>` : ''}
                ${props.historical_flood ? 
                    '<div style="margin: 8px 0; color: #dc3545;"><i class="fas fa-exclamation-triangle"></i> Historical flooding</div>' : 
                    ''
                }
                ${showSyntheticLabels && props.synthetic_house ?
                    '<div style="margin: 8px 0; color:#6b7280;"><i class="fas fa-clone"></i> Synthetic dot</div>' : ''}
            </div>
        `;
        
        marker.bindPopup(popupContent);
        
        // Add click handler
        marker.on('click', function() {
            showLocationDetail(props);
        });
        
        // Add to layer
        marker.addTo(markersLayer);
    });
    
    console.log(`✓ Displayed ${features.length} markers on map`);
}

// ===== CHART CREATION =====
function createRiskChart(distribution) {
    const ctx = document.getElementById('riskChart').getContext('2d');
    
    if (riskChart) {
        riskChart.destroy();
    }
    
    riskChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Low', 'Moderate', 'High', 'Extreme'],
            datasets: [{
                data: [
                    distribution.low,
                    distribution.moderate,
                    distribution.high,
                    distribution.extreme
                ],
                backgroundColor: [
                    '#10b981',
                    '#f59e0b',
                    '#f97316',
                    '#ef4444'
                ],
                borderWidth: 0,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    console.log('✓ Risk chart created');
}

// ===== LOCATION DETAIL PANEL =====
function showLocationDetail(props) {
    const detailPanel = document.getElementById('location-detail');
    const detailContent = document.getElementById('detail-content');
    
    // Format content
    detailContent.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div>
                <h5 style="color: #667eea; margin-bottom: 12px;">
                    <i class="fas fa-chart-line"></i> Risk Assessment
                </h5>
                <div style="margin: 8px 0;">
                    <strong>Risk Level:</strong> 
                    <span class="badge badge-${props.risk_level.toLowerCase()}">${props.risk_level}</span>
                </div>
                <div style="margin: 8px 0;">
                    <strong>Probability:</strong> ${(props.flood_probability * 100).toFixed(2)}%
                </div>
                <div style="margin: 8px 0;">
                    <strong>Location ID:</strong> ${props.house_id}
                </div>
            </div>
            <div>
                <h5 style="color: #667eea; margin-bottom: 12px;">
                    <i class="fas fa-mountain"></i> Environmental Data
                </h5>
                <div style="margin: 8px 0;">
                    <strong>Elevation:</strong> ${props.elevation_m.toFixed(2)} meters
                </div>
                <div style="margin: 8px 0;">
                    <strong>Distance to Water:</strong> ${props.distance_to_water_m.toFixed(0)} meters
                </div>
                <div style="margin: 8px 0;">
                    <strong>Historical Flood:</strong> 
                    ${props.historical_flood ? 
                        '<span style="color: #dc3545;"><i class="fas fa-check-circle"></i> Yes</span>' : 
                        '<span style="color: #28a745;"><i class="fas fa-times-circle"></i> No</span>'
                    }
                </div>
            </div>
        </div>
        <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e9ecef;">
            <button class="btn btn-sm btn-primary" onclick="getLiveRisk(${props.house_id})">
                <i class="fas fa-cloud-sun"></i> Get Live Weather Risk
            </button>
        </div>
    `;
    
    // Show panel
    detailPanel.classList.add('active');
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // Close detail panel
    document.getElementById('detail-close').addEventListener('click', function() {
        document.getElementById('location-detail').classList.remove('active');
    });
    
    // Refresh data
    document.getElementById('refresh-btn').addEventListener('click', function() {
        this.querySelector('i').classList.add('fa-spin');
        loadStatistics();
        const anchor = userAnchor || map.getCenter();
        fetchAreaPredictions(anchor, areaRadiusMeters, getCurrentPrecipInches(), true);
        fetchBuildingEstimate(anchor, areaRadiusMeters);
        setTimeout(() => {
            this.querySelector('i').classList.remove('fa-spin');
        }, 1000);
    });
    
    // Fullscreen toggle
    document.getElementById('fullscreen-btn').addEventListener('click', function() {
        const mapWrapper = document.querySelector('.map-wrapper');
        if (!document.fullscreenElement) {
            mapWrapper.requestFullscreen();
            this.querySelector('i').classList.remove('fa-expand');
            this.querySelector('i').classList.add('fa-compress');
        } else {
            document.exitFullscreen();
            this.querySelector('i').classList.remove('fa-compress');
            this.querySelector('i').classList.add('fa-expand');
        }
    });
    
    // Theme toggle
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const cur = document.documentElement.getAttribute('data-theme') || 'dark';
            const next = (cur === 'dark') ? 'light' : 'dark';
            try { localStorage.setItem('theme', next); } catch {}
            document.documentElement.setAttribute('data-theme', next);
            const desired = (next === 'dark') ? baseTilesDark : baseTilesLight;
            if (baseTilesCurrent) { try { map.removeLayer(baseTilesCurrent); } catch {} }
            if (desired) { desired.addTo(map); baseTilesCurrent = desired; }
            renderVisualization();
        });
    }
    
    // Visualization toggle
    const vizToggle = document.getElementById('viz-toggle');
    if (vizToggle) {
        vizToggle.addEventListener('click', (e) => {
            const btn = e.target.closest('.viz-btn');
            btn.addEventListener('click', () => {
                vizToggle.querySelectorAll('.viz-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentVizMode = btn.dataset.mode;
                renderVisualization();
            });
        });
    }

    // Houses mode removed

    // Heat auto-scale toggle
    const heatNormBtn = document.getElementById('heatnorm-btn');
    if (heatNormBtn) {
        heatNormBtn.addEventListener('click', () => {
            heatAutoScale = !heatAutoScale;
            heatNormBtn.classList.toggle('active', heatAutoScale);
            renderVisualization();
        });
    }

    // Engine mode: always Algorithm (mode picker removed)
    
    // Precipitation slider (no auto-predict)
    const precipSlider = document.getElementById('precip-slider');
    const precipValue = document.getElementById('precip-value');
    if (precipSlider && precipValue) {
        precipSlider.addEventListener('input', function() {
            precipValue.textContent = parseFloat(this.value).toFixed(2);
        });
    }
    
    // Use My Location button
    const locateBtn = document.getElementById('locate-btn');
    if (locateBtn) {
        locateBtn.addEventListener('click', function() {
            if (!navigator.geolocation) {
                alert('Geolocation is not supported by your browser');
                return;
            }
            
            this.querySelector('i').classList.add('fa-spin');
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    userAnchor = { lat, lng };
                    
                    // Center map on user location
                    map.setView([lat, lng], 13);
                    
                    // Draw circle for the 5-mile radius
                    if (areaCircle) map.removeLayer(areaCircle);
                    areaCircle = L.circle([lat, lng], {
                        radius: areaRadiusMeters,
                        color: '#667eea',
                        fillColor: '#667eea',
                        fillOpacity: 0.1,
                        weight: 2
                    }).addTo(map);
                    
                    updateLocationLabelFromCenter();
                    this.querySelector('i').classList.remove('fa-spin');
                },
                (error) => {
                    console.error('Geolocation error:', error);
                    alert('Could not get your location: ' + error.message);
                    this.querySelector('i').classList.remove('fa-spin');
                }
            );
        });
    }
    
    // Radius slider
    const radiusSlider = document.getElementById('radius-slider');
    const radiusValue = document.getElementById('radius-value');
    if (radiusSlider && radiusValue) {
        radiusSlider.addEventListener('input', function() {
            radiusValue.textContent = parseFloat(this.value).toFixed(1);
        });
        radiusSlider.addEventListener('change', function() {
            const miles = parseFloat(this.value);
            areaRadiusMeters = miles * 1609.34;
            const anchor = userAnchor || map.getCenter();
            if (areaCircle) { try { map.removeLayer(areaCircle); } catch {} }
            areaCircle = L.circle([anchor.lat, anchor.lng], {
                radius: areaRadiusMeters,
                color: '#667eea', fillColor: '#667eea', fillOpacity: 0.1, weight: 2
            }).addTo(map);
        });
    }

    // Validation metrics removed (not needed for user-facing app)

    // Predict Button
    const predictBtn = document.getElementById('predict-btn');
    if (predictBtn) {
        predictBtn.addEventListener('click', function() {
            const anchor = userAnchor || map.getCenter();
            const precipInches = getCurrentPrecipInches();
            console.log(`🔮 Running prediction at ${anchor.lat.toFixed(4)}, ${anchor.lng.toFixed(4)} with ${precipInches}" rain`);
            fetchAreaPredictions(anchor, areaRadiusMeters, precipInches, true);
        });
    }

    console.log('✓ Event listeners set up');
}

// ===== LIVE RISK ASSESSMENT =====
function getLiveRisk(houseId) {
    // Find the location
    const location = allPredictions.find(f => f.properties.house_id === houseId);
    if (!location) return;
    
    const coords = location.geometry.coordinates;
    
    // Show loading state
    const detailContent = document.getElementById('detail-content');
    const originalContent = detailContent.innerHTML;
    detailContent.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin fa-2x"></i><p>Fetching live weather data...</p></div>';
    
    // Call API
    fetch('/api/live-risk', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            latitude: coords[1],
            longitude: coords[0]
        })
    })
    .then(response => response.json())
    .then(data => {
        // Display live risk
        detailContent.innerHTML = `
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <h5 style="margin: 0 0 8px 0;"><i class="fas fa-bolt"></i> Live Risk Assessment</h5>
                <p style="margin: 0; font-size: 14px; opacity: 0.9;">Updated: ${new Date(data.timestamp).toLocaleString()}</p>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                <div>
                    <h6 style="color: #667eea; margin-bottom: 8px;">Current Risk</h6>
                    <div style="font-size: 32px; font-weight: bold; color: ${data.risk.risk_color};">
                        ${(data.risk.flood_probability * 100).toFixed(1)}%
                    </div>
                    <span class="badge badge-${data.risk.risk_level.toLowerCase()}">${data.risk.risk_level}</span>
                    ${data.risk.weather_adjusted ? '<p style="margin-top: 8px; font-size: 12px; color: #ffc107;"><i class="fas fa-exclamation-triangle"></i> Adjusted for current weather</p>' : ''}
                </div>
                <div>
                    <h6 style="color: #667eea; margin-bottom: 8px;">Current Weather</h6>
                    ${data.weather ? `
                        <div style="font-size: 13px;">
                            <div style="margin: 4px 0;"><strong>Condition:</strong> ${data.weather.description}</div>
                            <div style="margin: 4px 0;"><strong>Temp:</strong> ${data.weather.temperature}°C</div>
                            <div style="margin: 4px 0;"><strong>Humidity:</strong> ${data.weather.humidity}%</div>
                            ${data.weather.precipitation_1h > 0 ? `<div style="margin: 4px 0; color: #ffc107;"><strong>Rain:</strong> ${data.weather.precipitation_1h}mm/hr</div>` : ''}
                        </div>
                    ` : '<p style="font-size: 13px; color: #6c757d;">Weather data unavailable</p>'}
                </div>
            </div>
            
            <div style="padding: 12px; background: #f8f9fa; border-radius: 8px; font-size: 13px;">
                <strong>Base Features:</strong><br>
                Elevation: ${data.base_features.elevation_m.toFixed(1)}m | 
                Distance to water: ${data.base_features.distance_to_water_m.toFixed(0)}m
            </div>
            
            <button class="btn btn-sm btn-secondary" style="margin-top: 12px;" onclick="document.getElementById('detail-content').innerHTML = \`${originalContent.replace(/`/g, '\\`').replace(/\$/g, '\\$')}\`">
                <i class="fas fa-arrow-left"></i> Back to Details
            </button>
        `;
    })
    .catch(error => {
        console.error('✗ Failed to get live risk:', error);
        detailContent.innerHTML = originalContent + '<div style="color: #dc3545; margin-top: 12px;"><i class="fas fa-times-circle"></i> Failed to fetch live data</div>';
    })
}

// ===== UTILITY FUNCTIONS =====
function formatNumber(num) {
    return new Intl.NumberFormat().format(num);
}

function formatPercentage(num) {
    return (num * 100).toFixed(1) + '%';
}

function getColorForProbability(p) {
    const t = Math.max(0, Math.min(1, Number(p)));
    // Interpolate between green (0) -> yellow (0.4) -> orange (0.6) -> red (1)
    const stops = [
        {v:0.0, r:16,  g:185, b:129},  // #10b981
        {v:0.4, r:245, g:158, b:11},   // #f59e0b
        {v:0.6, r:249, g:115, b:22},   // #f97316
        {v:1.0, r:239, g:68,  b:68}    // #ef4444
    ];
    let a = stops[0], b = stops[stops.length-1];
    for (let i=0; i<stops.length-1; i++) {
        if (t >= stops[i].v && t <= stops[i+1].v) { a = stops[i]; b = stops[i+1]; break; }
    }
    const span = b.v - a.v || 1;
    const k = (t - a.v) / span;
    const R = Math.round(a.r + (b.r - a.r) * k);
    const G = Math.round(a.g + (b.g - a.g) * k);
    const B = Math.round(a.b + (b.b - a.b) * k);
    return `rgb(${R}, ${G}, ${B})`;
}

function getCurrentPrecipInches() {
    // Get current precipitation value from slider
    const slider = document.getElementById('precip-slider');
    return slider ? parseFloat(slider.value) : 0;
}

// ===== REAL-TIME PANELS =====

function refreshForecast(center) {
    const c = center || (map && map.getCenter()); if (!c) return Promise.resolve();
    return fetch('/api/forecast-risk', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude: c.lat, longitude: c.lng })
    })
    .then(r => r.json())
    .then(j => {
        const list = document.getElementById('forecast-list');
        if (!list) return;
        if (!j || j.error) { list.innerHTML = '<div>Forecast unavailable</div>'; return; }
        list.innerHTML = '';
        (j.forecast || []).forEach(row => {
            const d = document.createElement('div');
            d.textContent = `${row.hours}h → ${(row.probability*100).toFixed(1)}% (QPF ${row.precip_inches.toFixed(2)} in)`;
            list.appendChild(d);
        });
    }).catch(()=>{});
}

function refreshGauges(center) {
    const c = center || (map && map.getCenter()); if (!c) return Promise.resolve();
    const km = areaRadiusMeters / 1000.0;
    return fetch(`/api/usgs-gauges?lat=${c.lat}&lon=${c.lng}&radius_km=${km.toFixed(1)}`)
    .then(r => r.json())
    .then(j => {
        const list = document.getElementById('gauges-list');
        if (!list) return;
        if (!j || j.error) { list.innerHTML = '<div>Gauges unavailable</div>'; return; }
        list.innerHTML = '';
        (j.gauges || []).slice(0,8).forEach(g => {
            const d = document.createElement('div');
            d.textContent = `${g.name || g.site}: ${g.gage_height_ft != null ? g.gage_height_ft.toFixed(2)+' ft' : '-'} • ${g.discharge_cfs != null ? Math.round(g.discharge_cfs)+' cfs' : '-'}`;
            list.appendChild(d);
        });
        if ((j.gauges || []).length === 0) list.innerHTML = '<div>No gauges in range</div>';
    }).catch(()=>{});
}

function refreshAlerts(center) {
    const c = center || (map && map.getCenter()); if (!c) return Promise.resolve();
    return fetch(`/api/nws/alerts?lat=${c.lat}&lon=${c.lng}`)
    .then(r => r.json())
    .then(j => {
        const list = document.getElementById('alerts-list');
        if (!list) return;
        if (!j || j.error) { list.innerHTML = '<div>Alerts unavailable</div>'; return; }
        list.innerHTML = '';
        (j.alerts || []).slice(0,6).forEach(a => {
            const d = document.createElement('div');
            d.textContent = `${a.event}: ${a.headline || ''}`;
            list.appendChild(d);
        });
        if ((j.alerts || []).length === 0) list.innerHTML = '<div>No active alerts</div>';
    }).catch(()=>{});
}

function updateAreaStatsFromFeatures(features) {
    // Update statistics based on grid points only
    if (!Array.isArray(features) || features.length === 0) {
        console.log('No features to update stats from');
        return;
    }
    
    // Calculate risk distribution
    const dist = {
        low: 0,
        moderate: 0,
        high: 0,
        extreme: 0
    };
    
    features.forEach(f => {
        const prob = f.properties.flood_probability || 0;
        if (prob < 0.2) dist.low++;
        else if (prob < 0.4) dist.moderate++;
        else if (prob < 0.6) dist.high++;
        else dist.extreme++;
    });
    
    const totalPoints = features.length;
    const atRiskPoints = dist.high + dist.extreme;
    const atRiskPct = totalPoints > 0 ? (atRiskPoints / totalPoints) * 100 : 0;
    
    // Update the stats display (grid points only, no house scaling)
    document.getElementById('stat-low').textContent = formatNumber(dist.low);
    document.getElementById('stat-moderate').textContent = formatNumber(dist.moderate);
    document.getElementById('stat-high').textContent = formatNumber(dist.high);
    document.getElementById('stat-extreme').textContent = formatNumber(dist.extreme);
    const totalLocEl = document.getElementById('total-locations');
    if (totalLocEl) totalLocEl.textContent = formatNumber(totalPoints);
    
    // Update locations at risk (not "homes")
    const harEl = document.getElementById('homes-at-risk');
    const harPctEl = document.getElementById('homes-at-risk-pct');
    if (harEl) harEl.textContent = formatNumber(atRiskPoints);
    if (harPctEl) harPctEl.textContent = atRiskPct.toFixed(1);
    
    // Update the pie chart to match
    createRiskChart(dist);
    
    console.log(`✓ Updated stats: ${totalPoints} grid points, ${atRiskPoints} at risk (${atRiskPct.toFixed(1)}%)`);
}

console.log('✓ Flood Sentinel initialized successfully');

// ===== ELEVATION 3D VIEWER =====
async function openElevation3D() {
    const center = userAnchor || map.getCenter();
    const payload = {
        latitude: center.lat,
        longitude: center.lng,
        radius_meters: areaRadiusMeters,
        grid: 60
    };
    const res = await fetch('/api/elevation-grid', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!data || data.error) { console.warn('Elevation grid failed'); return; }
    const container = document.getElementById('elev3d-container');
    container.innerHTML = '';
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth/container.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    // Build geometry from grid
    const rows = data.rows, cols = data.cols, Z = data.z;
    const geometry = new THREE.PlaneGeometry(1, 1, cols-1, rows-1);
    // Normalize Z
    let zmin = Infinity, zmax = -Infinity;
    for (let r=0; r<rows; r++) { for (let c=0; c<cols; c++) { const z = Z[r][c]; if (z<zmin) zmin=z; if (z>zmax) zmax=z; } }
    const scaleZ = 1.0 / Math.max(1, (zmax - zmin));
    const verts = geometry.attributes.position;
    for (let i=0; i<verts.count; i++) {
        const r = Math.floor(i / cols), c = i % cols;
        const z = (Z[r][c] - zmin) * scaleZ;
        verts.setZ(i, z * 0.35); // exaggeration
    }
    verts.needsUpdate = true;
    geometry.computeVertexNormals();

    // Simple color by elevation
    const colors = [];
    for (let r=0; r<rows; r++) {
        for (let c=0; c<cols; c++) {
            const t = (Z[r][c] - zmin) * scaleZ;
            const col = new THREE.Color().setHSL((0.33 - 0.33*t), 0.8, 0.5);
            colors.push(col.r, col.g, col.b);
        }
    }
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    const material = new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, metalness: 0.05, roughness: 0.9 });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.rotation.x = -Math.PI/2;
    scene.add(mesh);

    const light = new THREE.DirectionalLight(0xffffff, 0.9); light.position.set(1,1,1); scene.add(light);
    const amb = new THREE.AmbientLight(0xffffff, 0.4); scene.add(amb);
    camera.position.set(0.7, 0.7, 0.7);
    controls.update();

    const animate = function () { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); };
    animate();
}
