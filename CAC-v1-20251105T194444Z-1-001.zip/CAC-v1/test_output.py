import sys
print("=" * 50)
print("TEST OUTPUT - If you see this, Python is working!")
print("=" * 50)
sys.stdout.flush()
print("\nPython version:", sys.version)
sys.stdout.flush()
